import { useState } from "react";
import axios from "axios";

function CreateProjectModal({ isOpen, onClose }) {
    const [nomProjet, setNomProjet] = useState("");
    const [cle, setCle] = useState("");

    const [etats, setEtats] = useState([
        "À faire",
        "En cours",
        "Revue en cours",
        "Terminé",
    ]);

    const ajouterEtat = () => {setEtats([...etats, ""]);};

    const modifierEtat = (index, valeur) => {
        const nouveauxEtats = [...etats];
        nouveauxEtats[index] = valeur;
        setEtats(nouveauxEtats);
    };

    const supprimerEtat = (index) => {
        const nouveauxEtats = etats.filter((_, i) => i !== index);
        setEtats(nouveauxEtats);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const projet = {nomProjet, cle, etats};

        try {
        await axios.post(
            "http://localhost:8080/api/projets",
            projet
        );

        alert("Projet créé avec succès");

        setNomProjet("");
        setCle("");
        setEtats([
            "À faire",
            "En cours",
            "Revue en cours",
            "Terminé",
        ]);

        onClose();
        } catch (error) {
        console.error(error);
        alert("Erreur lors de la création du projet");
        }
    };

    if (!isOpen) return null;

    return (
        <div className="modal-overlay">
        <div className="modal-content">
            <h2>Créer un projet</h2>

            <form onSubmit={handleSubmit}>
            <div className="form-group">
                <label>Nom du projet *</label>
                <input type="text" value={nomProjet} onChange={(e) => setNomProjet(e.target.value)} required/>
            </div>

            <div className="form-group">
                <label>Clé du projet *</label>
                <input type="text" value={cle} onChange={(e) => setCle(e.target.value.toUpperCase())} required/>
            </div>

            <hr />

            <h3>États</h3>

            {etats.map((etat, index) => (
                <div
                key={index}
                style={{
                    display: "flex",
                    gap: "10px",
                    marginBottom: "10px",
                }}
                >
                <input type="text" value={etat} onChange={(e) => modifierEtat(index, e.target.value)} required style={{ flex: 1 }}/>
                <button type="button" onClick={() => supprimerEtat(index)}>
                    🗑
                </button>
                </div>
            ))}

            <button type="button" onClick={ajouterEtat}>+ Ajouter un état</button>
            <div style={{marginTop: "20px",display: "flex",justifyContent: "flex-end",gap: "10px",}}>
                <button type="button" onClick={onClose}>Annuler</button>
                <button type="submit">Créer le projet</button>
            </div>
            </form>
        </div>
        </div>
    );
}

export default CreateProjectModal;